// One callback→Promise bridge for every chrome.* API the addon calls;
// each module used to hand-roll its own copy of this dance.
export function callChrome(chromeApi, target, method, ...args) {
  return new Promise((resolve, reject) => {
    target[method](...args, (result) => {
      const lastError = chromeApi.runtime?.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      resolve(result);
    });
  });
}
