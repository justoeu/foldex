import { SYNC_ALARM, ensureSyncAlarm, syncTags } from "./sync.js";

// Non-persistent MV3: alarms wake this worker; the sync itself re-checks the
// prefs.sync gate at fire time (sync.js), so no listener state is kept here.
chrome.runtime.onInstalled.addListener(() => void ensureSyncAlarm());
chrome.runtime.onStartup.addListener(() => void ensureSyncAlarm());

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) void syncTags();
});
