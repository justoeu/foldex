import { listTags } from "./api.js";
import { loadSettings } from "./storage.js";
import { callChrome } from "./util.js";

export const SYNC_ALARM = "foldex:tag-sync";
export const SYNC_PERIOD_MINUTES = 60;

// The alarm exists whenever the service worker is awake; the gate is evaluated
// at fire time so flipping the pref needs no extra messaging.
export function shouldSyncTags(settings) {
  // A credential-less sync would 401 every hour for nothing.
  return Boolean(settings?.prefs?.sync && settings?.server && settings?.token);
}

function writeSyncedTags(payload, chromeApi) {
  return callChrome(chromeApi, chromeApi.storage.local, "set", payload);
}

// The alarm's existence follows the stored pref so flipping it takes effect
// without waiting for the service worker to restart; the fire-time gate in
// syncTags still re-checks credentials on every tick.
export async function ensureSyncAlarm(chromeApi = chrome) {
  let settings = null;
  try {
    settings = await loadSettings(chromeApi);
  } catch {
    // A storage failure must not tear down an alarm that may still be right.
    return;
  }
  try {
    if (settings.prefs.sync) {
      chromeApi.alarms.create(SYNC_ALARM, { periodInMinutes: SYNC_PERIOD_MINUTES });
    } else {
      chromeApi.alarms.clear(SYNC_ALARM);
    }
  } catch {
    // Best-effort, like every other ambient lifecycle call here.
  }
}

export async function syncTags({ chromeApi = chrome, fetchImpl = fetch, now = Date.now } = {}) {
  const settings = await loadSettings(chromeApi);
  if (!shouldSyncTags(settings)) return { synced: false, reason: "disabled" };

  try {
    const tags = await listTags(settings, { chromeApi, fetchImpl });
    const payload = { syncedTags: tags, syncedTagsAt: now() };
    await writeSyncedTags(payload, chromeApi);
    return { synced: true, tags: tags.length };
  } catch (error) {
    // The service worker has no UI to surface failures to — a failed hourly
    // sync just means the cache stays stale until the next tick.
    return { synced: false, reason: "error", error: error.message };
  }
}
