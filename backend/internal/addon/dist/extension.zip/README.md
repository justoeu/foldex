# foldex-addon

Extensão Chrome (Manifest V3) do [Foldex](../foldex) — salve qualquer página na sua base em dois cliques: título, pasta, tags, nota e screenshot (área visível ou página inteira por scroll+stitch).

Projeto **independente e separado** do app. O repo `foldex` importa o zip pronto (`make extension`) e embute no backend; o download sai da área admin do Foldex.

## Desenvolvimento

```bash
npm test          # node --test test/ (zero dependências)
```

Estrutura:
- `manifest.json` — MV3; permissões: `activeTab`, `storage`, `scripting`, `alarms` + `optional_host_permissions` (origin do servidor pedido em runtime)
- `popup.html` / `popup.js` / `popup.css` — popup de 2 painéis (novo link / configurações), 404×600
- `capture.js` — captura visível + costura full-page (math pura em `capture.js`, chrome-glue injetado nos testes)
- `api.js` — client da API do Foldex (`Bearer` token, error mapping)
- `storage.js` / `state.js` / `sync.js` — settings, reducers puros, service worker de sync de tags (alarme horário)
- `_locales/{en,pt,es}` — i18n da extensão (parity testada)
- `fonts/` — Outfit 400–800 + JetBrains Mono 400–700 (woff2 embutidas)

## Versionamento

**Lockstep com o app Foldex**: `manifest.json` version == `web/package.json` version do foldex. O `make extension` do repo foldex **recusa** importar se as versões divergirem, e o CI do foldex valida o embed commitado (`dist/version.txt` == versão do app).

Fluxo de release (do lado do foldex):
1. Bump da versão aqui (`manifest.json` + `package.json`), commit.
2. No repo foldex: `make release-patch` (ou minor) — o script re-importa o zip e inclui no bump commit.

## Contrato com o app

Autenticação: API token (`fx_...`) criado em **Perfil → Tokens** no Foldex (1 token ativo por conta; Rotacionar para trocar). Endpoints usados: `/api/tags`, `/api/folders`, `/api/links`, `/api/links/{id}/image`, `/api/stats/summary`, `/api/auth/identities`.

Segurança: token guardado em `chrome.storage.local`; `https://` obrigatório fora de loopback (INV-093); sem `<all_urls>` — permissão de host pedida por origin em runtime.
