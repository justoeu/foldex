# foldex-addon

Extensão Chrome (Manifest V3) do [Foldex](https://github.com/justoeu/foldex) — o bookmarking self-hosted. Salve a página em que você está direto na sua base, em dois cliques: título, pasta, tags, nota e screenshot (área visível ou página inteira).

> Repositório **privado**, projeto **independente** do app. O repo `foldex` importa o zip pronto (`make extension`) e o distribui pela área admin.

---

## Como funciona

### O fluxo de salvamento (painel "Novo link")

1. **Página ativa** — ao abrir o popup (ícone ou `⌘⇧S` / `Ctrl+Shift+S`), a extensão lê o tab ativo (título + URL) e pré-preenche o campo **Título** (editável).
2. **Imagem do site** — toggle `Área visível | Página inteira`:
   - *Área visível*: uma chamada `chrome.tabs.captureVisibleTab`.
   - *Página inteira*: orquestração scroll+stitch — injeta script no tab para ler dimensões/`devicePixelRatio`, rola a página passo a passo (com double-rAF de settle por passo), captura cada viewport e **composição tile-a-tile** num canvas offscreen (1 canvas + ≤1 tile decodificado por vez; strings de tile são liberadas após o draw). Tetos de segurança: **máx. 40 tiles** e **2²⁸ px de canvas** — páginas gigantes degradam para captura da área visível (avisado no caption). Limitações conhecidas do método: elementos `position:sticky` repetem por passo; imagens lazy só carregam ao rolar.
3. **Pasta** — grade com as pastas da conta (+ contagem). `＋ Nova pasta` cria inline (nome + 6 cores da paleta) via `POST /api/folders` e seleciona.
4. **Tags** — chips toggáveis (existentes via `GET /api/tags`); digitar + `Enter` cria nova (viaja como `pending_tags` no save).
5. **Nota (opcional)** — vira `description` do link.
6. **Salvar no Foldex** — `POST /api/links` e, em sucesso, upload do PNG (`POST /api/links/{id}/image`, multipart). Falha no upload **não** desfaz o link: sucesso com meta "sem imagem". Painel verde `✓ Salvo em {pasta}` + preferência *fechar popup após salvar*.

### Conexão (painel "Configurações")

- **Endereço do servidor** — a URL da sua instância Foldex (ex.: `https://foldex.seudominio`). Normalizada em toda chamada: `https://` obrigatório fora de loopback (`http://` só para `localhost`/`127.0.0.1`/`::1` — bearer em clear-text é recusado, mesmo invariant INV-093 do backend); sem credenciais na URL; path de reverse-proxy é preservado.
- **API token** — criado no app em **Perfil → Tokens** (`fx_...`; 1 token ativo por conta; *Rotacionar* para trocar). Guardado em `chrome.storage.local`.
- **Testar conexão** — valida token + servidor e mostra conta/links/pastas + latência; 401 e sem-resposta têm cards próprios.
- **Padrões de captura** — capturar automaticamente ao abrir o popup · fechar popup após salvar · sincronizar tags do servidor.
- **Pasta padrão** — pré-selecionada a cada salvamento.

A permissão de host para o servidor **não** é pedida na instalação: `optional_host_permissions` + `chrome.permissions.request` por origin, no gesto de salvar configurações.

### Service worker (background)

Alarme horário que sincroniza a lista de tags (`chrome.alarms`), **provisionado/limpo conforme a preferência** `sync` — desligado = alarme removido, sem wake-up. Falha de rede/credencial é silenciosa (cache serve o popup).

---

## Contrato com a API Foldex

Autenticação: header `Authorization: Bearer <token>` em toda chamada. Escopo do token: `content` (o backend recusa tokens em superfícies admin/settings/auth sensíveis — INV-023).

| Método | Rota | Uso |
|---|---|---|
| GET | `/api/tags` | chips + cache de sync |
| GET | `/api/folders` | grade de pastas (+ teste de conexão) |
| POST | `/api/folders` | ＋Nova pasta (name, color) |
| POST | `/api/links` | salvar (url, title, description, folder_id, tag_ids, pending_tags) |
| POST | `/api/links/{id}/image` | upload do screenshot (multipart PNG) |
| GET | `/api/stats/summary` | contador de links (teste de conexão) |
| GET | `/api/auth/identities` | conta (teste de conexão) |

Erros seguem o envelope do Foldex (`{error:{code,message}}`); 401/403 têm copy dedicada ("token recusado").

## Arquitetura

Módulos ES puros (sem bundler, zero dependências):

| Arquivo | Papel |
|---|---|
| `popup.html` / `popup.css` / `popup.js` | UI 2 painéis (404×600) + controller (DI de `chromeApi`/`fetchImpl`/`documentApi`) |
| `capture.js` | math pura do plano/stitch (`capturePlan`, `axisSteps`, `drawTileOnCanvas`) + chrome-glue fino (`planFullCapture`, `captureStep`) |
| `api.js` | client HTTP (URL join, bearer, error mapping, multipart) |
| `storage.js` | wrapper de `chrome.storage.local` (`server`, `token`, `prefs`, `defaultFolderId`) + migração de chaves legadas |
| `state.js` | reducers puros (chips, `tag_ids` vs `pending_tags`, hints) |
| `sync.js` | alarme horário de tags + lifecycle (`ensureSyncAlarm`) |
| `config.js` | normalização de URL, regras de origin/loopback, permissões por origin |
| `util.js` | ponte callback→Promise compartilhada (`callChrome`) |
| `i18n.js` + `_locales/{en,pt,es}` | i18n nativo do Chrome (parity testada) |
| `background.js` | service worker MV3 (onInstalled/onStartup → alarme) |
| `options.html` / `options.js` | fallback de configurações fora do popup |

## Segurança

- Token **nunca** em URL ou log; só header, só para o origin configurado.
- `https://` fora de loopback (INV-093); sem `<all_urls>` — permissão por origin em runtime.
- `scripting.executeScript` apenas no tab ativo (`activeTab`); sem `innerHTML`; sem `externally_connectable`.
- Permissões do manifest: `activeTab`, `storage`, `scripting`, `alarms`.

## Desenvolvimento

```bash
npm test        # node --test test/ (75 testes, zero dependências)
```

- Testes em `test/*.test.mjs`: math de captura (boundaries dos caps, dpr, degradê), client de API (todas as rotas, error mapping), storage (defaults/normalização/migração), reducers, alarme (ligado/desligado/falhas), manifest (shape, permissões, comando), controller do popup (fluxo save, fallback sem-imagem, revoke de object URLs), i18n parity en/pt/es.
- Carregar localmente: `chrome://extensions` → Developer mode → Load unpacked → aponte para esta pasta.

## Build, versionamento e release

- **Lockstep com o app**: `manifest.json`/`package.json` version == versão do foldex (`web/package.json`). O `make extension` do foldex **recusa** importar em divergência, o CI do foldex valida o embed commitado, e o `release.sh` re-importa o zip no bump.
- Fluxo de release (no repo foldex): 1) bump da versão aqui + commit; 2) lá, `make release-patch|minor` — o script importa o zip e inclui no commit de bump.
- O zip importado é **determinístico** (ordem fixa, mtime 1980-01-01, deflate 9) e **exclui** testes/`node_modules`/dotfiles.

## Distribuição

Admins baixam o zip na área admin do Foldex (`GET /api/admin/addon/download`; versão no header `X-Addon-Version`). Instalação: extrair → `chrome://extensions` → Developer mode → Load unpacked.
