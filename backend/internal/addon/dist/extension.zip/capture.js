// Pure stitch math — no chrome dependency, fully covered by node --test.

import { callChrome } from "./util.js";

// Chrome caps canvas area at 2^28 pixels; beyond the tile cap the capture
// also stops being worth its memory, so both degrade to a viewport shot.
export const MAX_TILES = 40;
export const MAX_CANVAS_PIXELS = 2 ** 28;

// Viewport-sized steps over one axis. The last step aligns with the edge so
// pages that are not an exact multiple never overshoot (and sticky headers
// repeat at most once per axis edge).
export function axisSteps(total, viewport) {
  // A hidden or crashed tab can report a zero-dimension viewport; stepping
  // into it would loop forever, so collapse to a degenerate step the
  // caller's capture then fails on its own terms.
  if (viewport <= 0) return [0];
  const last = Math.max(0, total - viewport);
  const steps = [];
  for (let offset = 0; offset < last; offset += viewport) {
    steps.push(offset);
  }
  steps.push(last);
  return steps;
}

export function capturePlan({
  scrollWidth,
  scrollHeight,
  viewportWidth,
  viewportHeight,
  devicePixelRatio,
}) {
  const xs = axisSteps(scrollWidth, viewportWidth);
  const ys = axisSteps(scrollHeight, viewportHeight);
  const steps = [];
  for (const y of ys) {
    for (const x of xs) {
      steps.push({ x, y });
    }
  }
  const canvasWidth = Math.round(scrollWidth * devicePixelRatio);
  const canvasHeight = Math.round(scrollHeight * devicePixelRatio);
  if (steps.length > MAX_TILES || canvasWidth * canvasHeight > MAX_CANVAS_PIXELS) {
    return {
      steps: [{ x: 0, y: 0 }],
      cols: 1,
      rows: 1,
      canvasWidth: Math.round(viewportWidth * devicePixelRatio),
      canvasHeight: Math.round(viewportHeight * devicePixelRatio),
      dpr: devicePixelRatio,
      degraded: "too_large",
    };
  }
  return {
    steps,
    cols: xs.length,
    rows: ys.length,
    canvasWidth,
    canvasHeight,
    dpr: devicePixelRatio,
  };
}

// Chrome-dependent capture, thin and injected for tests.

const PAGE_METRICS = () => ({
  scrollWidth: document.documentElement.scrollWidth,
  scrollHeight: document.documentElement.scrollHeight,
  viewportWidth: window.innerWidth,
  viewportHeight: window.innerHeight,
  devicePixelRatio: window.devicePixelRatio,
});

// Double rAF inside the page: scrollTo only schedules, the compositor needs
// two frames before captureVisibleTab sees the new position.
const SCROLL_AND_SETTLE = (x, y) =>
  new Promise((resolve) => {
    window.scrollTo(x, y);
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  });

export function getPageMetrics(tabId, chromeApi = chrome) {
  return callChrome(chromeApi, chromeApi.scripting, "executeScript", {
    target: { tabId },
    func: PAGE_METRICS,
  }).then((results) => results[0].result);
}

export function scrollToOffset(tabId, { x, y }, chromeApi = chrome) {
  return callChrome(chromeApi, chromeApi.scripting, "executeScript", {
    target: { tabId },
    func: SCROLL_AND_SETTLE,
    args: [x, y],
  });
}

export function captureVisible(chromeApi = chrome) {
  return callChrome(chromeApi, chromeApi.tabs, "captureVisibleTab", null, {
    format: "png",
  });
}

export async function planFullCapture(tabId, chromeApi = chrome) {
  const metrics = await getPageMetrics(tabId, chromeApi);
  return { metrics, plan: capturePlan(metrics) };
}

export async function captureStep(tabId, step, chromeApi = chrome) {
  await scrollToOffset(tabId, step, chromeApi);
  return captureVisible(chromeApi);
}

// Pure placement math: the tile lands at the dpr-scaled, rounded step
// offset. Keeping this free of Image/canvas wiring is what makes the
// compose loop testable outside a browser.
export function drawTileOnCanvas(ctx, plan, step, img) {
  ctx.drawImage(img, Math.round(step.x * plan.dpr), Math.round(step.y * plan.dpr));
}
